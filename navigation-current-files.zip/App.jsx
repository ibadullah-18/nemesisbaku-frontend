import { LanguageProvider } from "./i18n/LanguageContext";
import AppRoutes from "./routes/AppRoutes";
import UserToastHost from "./components/common/UserToastHost";

export default function App() {
  return (
    <LanguageProvider>
      <style>
        {`
          * {
            box-sizing: border-box;
          }

          html {
            background: #fafafa;
          }

          body {
            margin: 0;
            background: #fafafa;
            color: #111111;
            font-family: "Nunito Sans", Inter, Arial, sans-serif;
          }

          button,
          input,
          textarea,
          select {
            font: inherit;
          }

          input[type="password"]::-ms-reveal,
          input[type="password"]::-ms-clear {
            display: none;
          }

          input::-webkit-credentials-auto-fill-button,
          input::-webkit-contacts-auto-fill-button {
            visibility: hidden;
            display: none !important;
            pointer-events: none;
          }

          @keyframes pageSlideIn {
            from {
              opacity: 0;
              transform: translateY(14px);
            }

            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
              scroll-behavior: auto !important;
              animation-duration: 0.01ms !important;
              animation-iteration-count: 1 !important;
              transition-duration: 0.01ms !important;
            }
          }
        `}
      </style>
      <UserToastHost />
      <AppRoutes />
    </LanguageProvider>
  );
}