import { lazy, Suspense, useEffect } from "react";
import {
  Navigate,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";

import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";

const HomePage = lazy(() => import("../pages/home/HomePage"));
const SearchPage = lazy(
  () => import("../components/common/SearchOverlay"),
);
const FavoritesPage = lazy(
  () => import("../pages/favorites/FavoritesPage"),
);
const BasketPage = lazy(() => import("../pages/basket/BasketPage"));
const ProfilePage = lazy(() => import("../pages/profile/ProfilePage"));
const LoginPage = lazy(() => import("../pages/auth/LoginPage"));
const RegisterPage = lazy(() => import("../pages/auth/RegisterPage"));
const ForgotPasswordPage = lazy(
  () => import("../pages/auth/ForgotPasswordPage"),
);

const ProductDetailsPage = lazy(
  () => import("../pages/product/ProductDetailsPage"),
);

const MyOrdersPage = lazy(
  () => import("../pages/orders/MyOrdersPage"),
);
const OrderDetailsPage = lazy(
  () => import("../pages/orders/OrderDetailsPage"),
);

const CheckoutPage = lazy(
  () => import("../pages/checkout/CheckoutPage"),
);
const OrderSuccessPage = lazy(
  () => import("../pages/checkout/OrderSuccessPage"),
);
const OrderFailedPage = lazy(
  () => import("../pages/checkout/OrderFailedPage"),
);

const AddressesPage = lazy(
  () => import("../pages/profile/AddressesPage"),
);
const ProfileSettingsPage = lazy(
  () => import("../pages/profile/ProfileSettingsPage"),
);
const AccountSettingsPage = lazy(
  () => import("../pages/profile/AccountSettingsPage"),
);
const SecuritySettingsPage = lazy(
  () => import("../pages/profile/SecuritySettingsPage"),
);
const LoyaltyCardInfoPage = lazy(
  () => import("../pages/profile/LoyaltyCardPage"),
);

const PromoPage = lazy(() => import("../pages/promo/PromoPage"));
const NotFoundPage = lazy(
  () => import("../pages/error/NotFoundPage"),
);

const InfoAddressPage = lazy(
  () => import("../pages/info/InfoAddressPage"),
);
const DeliveryPage = lazy(
  () => import("../pages/info/DeliveryPage"),
);
const ReturnPolicyPage = lazy(
  () => import("../pages/info/ReturnPolicyPage"),
);
const AboutPage = lazy(() => import("../pages/info/AboutPage"));
const CareerPage = lazy(() => import("../pages/info/CareerPage"));
const StoresPage = lazy(() => import("../pages/info/StoresPage"));

const SuperAdminLogin = lazy(
  () => import("../pages/admin/SuperAdminLogin"),
);
const AdminLogin = lazy(() => import("../pages/admin/AdminLogin"));

const AdminLayout = lazy(
  () => import("../components/admin/AdminLayout"),
);
const AdminProtectedRoute = lazy(
  () => import("../components/admin/AdminProtectedRoute"),
);

const AdminDashboard = lazy(
  () => import("../pages/admin/AdminDashboard"),
);
const AdminProducts = lazy(
  () => import("../pages/admin/AdminProducts"),
);
const AdminProductDetails = lazy(
  () => import("../pages/admin/AdminProductDetails"),
);
const AdminAddProduct = lazy(
  () => import("../pages/admin/AdminAddProduct"),
);
const AdminEditProduct = lazy(
  () => import("../pages/admin/AdminEditProduct"),
);
const AdminCampaigns = lazy(
  () => import("../pages/admin/AdminCampaigns"),
);
const AdminPromoForm = lazy(
  () => import("../pages/admin/AdminPromoForm"),
);
const AdminOrders = lazy(
  () => import("../pages/admin/AdminOrders"),
);
const AdminOrderDetails = lazy(
  () => import("../pages/admin/AdminOrderDetails"),
);
const AdminAuditLogs = lazy(
  () => import("../pages/admin/AdminAuditLogs"),
);
const AdminCategories = lazy(
  () => import("../pages/admin/AdminCategories"),
);
const AdminBrands = lazy(
  () => import("../pages/admin/AdminBrands"),
);
const AdminUsers = lazy(
  () => import("../pages/admin/AdminUsers"),
);
const AdminSizes = lazy(
  () => import("../pages/admin/AdminSizes"),
);
const AdminColors = lazy(
  () => import("../pages/admin/AdminColors"),
);
const AdminHomeSections = lazy(
  () => import("../pages/admin/AdminHomeSections"),
);
const AdminHomeSectionForm = lazy(
  () => import("../pages/admin/AdminHomeSectionForm"),
);
const AdminPromoCodes = lazy(
  () => import("../pages/admin/AdminPromoCodes"),
);
const AdminEmailAnnouncements = lazy(
  () => import("../pages/admin/AdminEmailAnnouncements"),
);
const AdminCouriers = lazy(
  () => import("../pages/admin/AdminCouriers"),
);

function RouteFallback({ fullPage = false }) {
  return (
    <div
      className={`bg-[#fafafa] ${
        fullPage
          ? "min-h-screen"
          : "min-h-[calc(100dvh-72px)]"
      }`}
      aria-hidden="true"
    />
  );
}

function PageShell({ children }) {
  const location = useLocation();

  useEffect(() => {
    const shouldRestoreProduct =
      location.pathname === "/" &&
      sessionStorage.getItem("nemesis_return_product_id");

    if (shouldRestoreProduct) return;

    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "auto",
    });
  }, [location.pathname]);

  return (
    <div className="animate-[pageSlideIn_0.38s_cubic-bezier(0.22,1,0.36,1)_both]">
      {children}
    </div>
  );
}

function Layout({ children }) {
  return (
    <>
      <Navbar />

      <PageShell>
        <Suspense fallback={<RouteFallback />}>
          {children}
        </Suspense>
      </PageShell>

      <Footer />
    </>
  );
}

function PublicPage({ children }) {
  return <Layout>{children}</Layout>;
}

function StandalonePage({ children }) {
  return (
    <Suspense fallback={<RouteFallback fullPage />}>
      {children}
    </Suspense>
  );
}

function AdminRoot({ panel, basePath, panelTitle }) {
  return (
    <Suspense fallback={<RouteFallback fullPage />}>
      <AdminProtectedRoute panel={panel}>
        <AdminLayout
          basePath={basePath}
          panel={panel}
          panelTitle={panelTitle}
        />
      </AdminProtectedRoute>
    </Suspense>
  );
}

function NotFoundRedirect() {
  const location = useLocation();

  return (
    <Navigate
      to="/404"
      replace
      state={{
        from: `${location.pathname}${location.search}`,
      }}
    />
  );
}

const publicRoutes = [
  { path: "/", Component: HomePage },
  { path: "/search", Component: SearchPage },
  { path: "/favorites", Component: FavoritesPage },
  { path: "/basket", Component: BasketPage },
  { path: "/profile", Component: ProfilePage },
  { path: "/login", Component: LoginPage },
  { path: "/register", Component: RegisterPage },
  { path: "/forgot-password", Component: ForgotPasswordPage },

  { path: "/products/:id", Component: ProductDetailsPage },

  { path: "/orders", Component: MyOrdersPage },
  { path: "/orders/:id", Component: OrderDetailsPage },

  { path: "/checkout", Component: CheckoutPage },
  { path: "/order-success", Component: OrderSuccessPage },
  { path: "/order-failed", Component: OrderFailedPage },

  { path: "/profile/settings", Component: ProfileSettingsPage },
  {
    path: "/profile/settings/addresses",
    Component: AddressesPage,
  },
  {
    path: "/profile/settings/account",
    Component: AccountSettingsPage,
  },
  {
    path: "/profile/settings/security",
    Component: SecuritySettingsPage,
  },
  {
    path: "/profile/loyalty-card",
    Component: LoyaltyCardInfoPage,
  },

  { path: "/infoAddress", Component: InfoAddressPage },
  { path: "/delivery", Component: DeliveryPage },
  { path: "/return-policy", Component: ReturnPolicyPage },
  { path: "/about", Component: AboutPage },
  { path: "/career", Component: CareerPage },
  { path: "/stores", Component: StoresPage },

  { path: "/promo/:id", Component: PromoPage },
  { path: "/404", Component: NotFoundPage },
];

export default function AppRoutes() {
  return (
    <Routes>
      {publicRoutes.map(({ path, Component }) => (
        <Route
          key={path}
          path={path}
          element={
            <PublicPage>
              <Component />
            </PublicPage>
          }
        />
      ))}

      <Route
        path="/SuperAdmin/login"
        element={
          <StandalonePage>
            <SuperAdminLogin />
          </StandalonePage>
        }
      />

      <Route
        path="/SuperAdmin"
        element={
          <AdminRoot
            panel="super"
            basePath="/SuperAdmin"
            panelTitle="Super Admin Panel"
          />
        }
      >
        <Route
          index
          element={
            <Navigate
              to="/SuperAdmin/dashboard"
              replace
            />
          }
        />

        <Route path="dashboard" element={<AdminDashboard />} />

        <Route path="products" element={<AdminProducts />} />
        <Route
          path="products/details/:id"
          element={<AdminProductDetails />}
        />
        <Route path="add-product" element={<AdminAddProduct />} />
        <Route
          path="products/:id"
          element={<AdminEditProduct />}
        />

        <Route path="campaigns" element={<AdminCampaigns />} />
        <Route
          path="campaigns/create"
          element={<AdminPromoForm mode="create" />}
        />
        <Route
          path="campaigns/:id"
          element={<AdminPromoForm mode="edit" />}
        />

        <Route path="orders" element={<AdminOrders />} />
        <Route
          path="orders/:id"
          element={<AdminOrderDetails />}
        />

        <Route path="audit-logs" element={<AdminAuditLogs />} />

        <Route path="categories" element={<AdminCategories />} />
        <Route path="brands" element={<AdminBrands />} />
        <Route path="sizes" element={<AdminSizes />} />
        <Route path="colors" element={<AdminColors />} />
        <Route path="users" element={<AdminUsers />} />

        <Route
          path="promo-codes"
          element={<AdminPromoCodes />}
        />
        <Route
          path="email-announcements"
          element={<AdminEmailAnnouncements />}
        />
        <Route path="couriers" element={<AdminCouriers />} />

        <Route
          path="home-sections"
          element={<AdminHomeSections />}
        />
        <Route
          path="home-sections/create"
          element={<AdminHomeSectionForm mode="create" />}
        />
        <Route
          path="home-sections/:id"
          element={<AdminHomeSectionForm mode="edit" />}
        />

        <Route path="*" element={<NotFoundRedirect />} />
      </Route>

      <Route
        path="/Admin/login"
        element={
          <StandalonePage>
            <AdminLogin />
          </StandalonePage>
        }
      />

      <Route
        path="/Admin"
        element={
          <AdminRoot
            panel="admin"
            basePath="/Admin"
            panelTitle="Admin Panel"
          />
        }
      >
        <Route
          index
          element={<Navigate to="/Admin/orders" replace />}
        />

        <Route path="orders" element={<AdminOrders />} />
        <Route
          path="orders/:id"
          element={<AdminOrderDetails />}
        />

        <Route path="couriers" element={<AdminCouriers />} />

        <Route path="products" element={<AdminProducts />} />
        <Route
          path="products/details/:id"
          element={<AdminProductDetails />}
        />
        <Route path="add-product" element={<AdminAddProduct />} />
        <Route
          path="products/:id"
          element={<AdminEditProduct />}
        />

        <Route path="categories" element={<AdminCategories />} />
        <Route path="brands" element={<AdminBrands />} />
        <Route path="sizes" element={<AdminSizes />} />
        <Route path="colors" element={<AdminColors />} />

        <Route path="campaigns" element={<AdminCampaigns />} />
        <Route
          path="campaigns/create"
          element={<AdminPromoForm mode="create" />}
        />
        <Route
          path="campaigns/:id"
          element={<AdminPromoForm mode="edit" />}
        />

        <Route
          path="home-sections"
          element={<AdminHomeSections />}
        />
        <Route
          path="home-sections/create"
          element={<AdminHomeSectionForm mode="create" />}
        />
        <Route
          path="home-sections/:id"
          element={<AdminHomeSectionForm mode="edit" />}
        />

        <Route
          path="promo-codes"
          element={<AdminPromoCodes />}
        />
        <Route
          path="email-announcements"
          element={<AdminEmailAnnouncements />}
        />

        <Route path="*" element={<NotFoundRedirect />} />
      </Route>

      <Route path="*" element={<NotFoundRedirect />} />
    </Routes>
  );
}