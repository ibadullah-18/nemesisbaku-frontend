import { useEffect, useRef, useState } from "react";
import {
  NavLink,
  useLocation,
  useSearchParams,
} from "react-router-dom";
import {
  FiArrowUpRight,
  FiClock,
  FiImage,
  FiSearch,
  FiTrendingUp,
  FiX,
} from "react-icons/fi";
import { apiFetch } from "../../api/apiFetch";
import { useLanguage } from "../../i18n/LanguageContext";
import { showUserToast } from "../../utils/userToast";
import SearchResultsSkeleton from "../search/SearchResultsSkeleton";

const MIN_QUERY_LENGTH = 2;
const SEARCH_DELAY = 280;
const RECENT_SEARCHES_KEY = "nemesisbaku_recent_searches";
const MAX_RECENT_SEARCHES = 6;

const popularSearches = [
  "Nike",
  "Adidas",
  "New Balance",
  "Jordan",
  "Puma",
];

const searchCopies = {
  az: {
    recent: "Son axtarışlar",
    popular: "Populyar axtarışlar",
    clear: "Təmizlə",
    result: "nəticə",
    loadError: "Axtarış zamanı xəta baş verdi.",
  },
  en: {
    recent: "Recent searches",
    popular: "Popular searches",
    clear: "Clear",
    result: "results",
    loadError: "An error occurred while searching.",
  },
  ru: {
    recent: "Недавние поиски",
    popular: "Популярные запросы",
    clear: "Очистить",
    result: "результатов",
    loadError: "При поиске произошла ошибка.",
  },
};

function normalizeProducts(response) {
  const data = response?.data ?? response;
  const nestedData = data?.data ?? data;

  const products =
    data?.items ||
    data?.products ||
    data?.result ||
    nestedData?.items ||
    nestedData?.products ||
    nestedData?.result ||
    (Array.isArray(nestedData) ? nestedData : []);

  return Array.isArray(products) ? products : [];
}

function getProductId(product) {
  return product?.id || product?.productId || "";
}

function getProductImage(product) {
  return (
    product?.mainImageUrl ||
    product?.imageUrl ||
    product?.images?.find((image) => image?.isMain)?.imageUrl ||
    product?.images?.[0]?.imageUrl ||
    product?.images?.[0]?.url ||
    ""
  );
}

function getProductPrices(product) {
  const originalPrice = Number(product?.price || 0);
  const discountPrice = Number(product?.discountPrice || 0);

  const hasDiscount =
    originalPrice > 0 &&
    discountPrice > 0 &&
    discountPrice < originalPrice;

  return {
    originalPrice,
    sellingPrice: hasDiscount ? discountPrice : originalPrice,
    hasDiscount,
    discountPercent: hasDiscount
      ? Math.round(
          ((originalPrice - discountPrice) / originalPrice) * 100,
        )
      : 0,
  };
}

function money(value) {
  return `${Number(value || 0).toFixed(2)} ₼`;
}

function readRecentSearches() {
  try {
    const stored = JSON.parse(
      localStorage.getItem(RECENT_SEARCHES_KEY) || "[]",
    );

    return Array.isArray(stored)
      ? stored.filter(Boolean).slice(0, MAX_RECENT_SEARCHES)
      : [];
  } catch {
    return [];
  }
}

function saveRecentSearch(searchValue) {
  const value = String(searchValue || "").trim();

  if (value.length < MIN_QUERY_LENGTH) {
    return readRecentSearches();
  }

  const current = readRecentSearches();

  const filtered = current.filter(
    (item) => item.toLocaleLowerCase() !== value.toLocaleLowerCase(),
  );

  const next = [value, ...filtered].slice(0, MAX_RECENT_SEARCHES);

  localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(next));

  return next;
}

export default function SearchPage() {
  const { text, lang } = useLanguage();
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  const currentLanguage = String(lang || "az").toLowerCase();
  const copy = searchCopies[currentLanguage] || searchCopies.az;

  const initialQuery = searchParams.get("q") || "";

  const requestIdRef = useRef(0);
  const requestControllerRef = useRef(null);
  const debounceTimerRef = useRef(null);
  const restoreScrollDoneRef = useRef(false);

  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchCompleted, setSearchCompleted] = useState(false);
  const [recentSearches, setRecentSearches] = useState(
    readRecentSearches,
  );

  const cleanQuery = query.trim();
  const searchIsReady = cleanQuery.length >= MIN_QUERY_LENGTH;

  useEffect(() => {
    window.clearTimeout(debounceTimerRef.current);
    requestControllerRef.current?.abort();

    if (!searchIsReady) {
      requestIdRef.current += 1;
      setSearchParams({}, { replace: true });
      setResults([]);
      setLoading(false);
      setSearchCompleted(false);
      return;
    }

    debounceTimerRef.current = window.setTimeout(() => {
      startSearch(cleanQuery);
    }, SEARCH_DELAY);

    return () => {
      window.clearTimeout(debounceTimerRef.current);
    };
  }, [query]);

  useEffect(() => {
    return () => {
      requestIdRef.current += 1;
      requestControllerRef.current?.abort();
      window.clearTimeout(debounceTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (
      restoreScrollDoneRef.current ||
      loading ||
      results.length === 0
    ) {
      return;
    }

    const savedScrollY = Number(
      location.state?.restoreSearchScrollY ??
        sessionStorage.getItem("nemesis_search_scroll_y"),
    );

    if (!Number.isFinite(savedScrollY) || savedScrollY < 0) {
      return;
    }

    restoreScrollDoneRef.current = true;

    let secondFrame;

    const firstFrame = window.requestAnimationFrame(() => {
      secondFrame = window.requestAnimationFrame(() => {
        window.scrollTo({
          top: savedScrollY,
          left: 0,
          behavior: "auto",
        });

        sessionStorage.removeItem("nemesis_search_scroll_y");
      });
    });

    return () => {
      window.cancelAnimationFrame(firstFrame);

      if (secondFrame) {
        window.cancelAnimationFrame(secondFrame);
      }
    };
  }, [loading, results.length, location.state]);

  async function startSearch(searchValue) {
    const normalizedValue = searchValue.trim();

    if (normalizedValue.length < MIN_QUERY_LENGTH) return;

    requestControllerRef.current?.abort();

    const controller = new AbortController();
    const requestId = ++requestIdRef.current;

    requestControllerRef.current = controller;

    setSearchParams(
      { q: normalizedValue },
      { replace: true },
    );

    try {
      setLoading(true);
      setSearchCompleted(false);

      const response = await apiFetch(
        `/api/Products?search=${encodeURIComponent(normalizedValue)}`,
        {
          signal: controller.signal,
        },
      );

      if (
        controller.signal.aborted ||
        requestId !== requestIdRef.current
      ) {
        return;
      }

      setResults(normalizeProducts(response));
      setSearchCompleted(true);
    } catch (error) {
      if (
        controller.signal.aborted ||
        requestId !== requestIdRef.current
      ) {
        return;
      }

      setResults([]);
      setSearchCompleted(true);

      showUserToast(
        error?.message || copy.loadError,
        "error",
      );
    } finally {
      if (
        !controller.signal.aborted &&
        requestId === requestIdRef.current
      ) {
        setLoading(false);
      }
    }
  }

  function submitSearch(event) {
    event.preventDefault();

    if (!searchIsReady) return;

    window.clearTimeout(debounceTimerRef.current);

    setRecentSearches(saveRecentSearch(cleanQuery));
    startSearch(cleanQuery);
  }

  function selectSearchKeyword(value) {
    setQuery(value);
    setRecentSearches(saveRecentSearch(value));
  }

  function clearSearch() {
    requestIdRef.current += 1;
    requestControllerRef.current?.abort();
    window.clearTimeout(debounceTimerRef.current);

    sessionStorage.removeItem("nemesis_search_scroll_y");

    setQuery("");
    setResults([]);
    setLoading(false);
    setSearchCompleted(false);
    setSearchParams({}, { replace: true });
  }

  function clearRecentSearches() {
    localStorage.removeItem(RECENT_SEARCHES_KEY);
    setRecentSearches([]);
  }

  function handleProductOpen() {
    setRecentSearches(saveRecentSearch(cleanQuery));

    sessionStorage.setItem(
      "nemesis_search_scroll_y",
      String(window.scrollY),
    );
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#fafafa] px-4 py-5 text-zinc-950 md:px-6 md:py-8">
      <section className="mx-auto max-w-[900px]">
        <form
          onSubmit={submitSearch}
          className="mb-7 flex items-center gap-3 border-b border-zinc-200/70 pb-5"
        >
          <div className="group flex h-[54px] flex-1 items-center gap-3 rounded-[19px] border border-zinc-200/80 bg-white px-4 shadow-[0_10px_32px_rgba(0,0,0,0.045)] transition duration-300 focus-within:border-zinc-400 focus-within:shadow-[0_16px_40px_rgba(0,0,0,0.07)] md:h-[60px] md:rounded-[22px] md:px-5">
            <FiSearch className="shrink-0 text-[20px] text-zinc-500 transition group-focus-within:text-zinc-950 md:text-[22px]" />

            <input
              autoFocus
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={text.searchPlaceholder}
              autoComplete="off"
              enterKeyHint="search"
              className="h-full min-w-0 flex-1 bg-transparent text-[16px] font-semibold outline-none placeholder:font-medium placeholder:text-zinc-400 md:text-[18px]"
            />
          </div>

          {query.length > 0 && (
            <button
              type="button"
              onClick={clearSearch}
              aria-label="Axtarışı təmizlə"
              className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-zinc-950 text-[21px] text-white shadow-[0_12px_30px_rgba(0,0,0,0.16)] transition hover:bg-zinc-800 active:scale-90 md:h-13 md:w-13"
            >
              <FiX />
            </button>
          )}
        </form>

        <div className="mb-5 flex min-h-10 items-end justify-between gap-4">
          <div>
            <p className="mb-1 text-[10px] font-extrabold uppercase tracking-[0.28em] text-zinc-400">
              nemesisbaku
            </p>

            <h1 className="text-[25px] font-extrabold tracking-[-0.04em] text-zinc-950 md:text-[34px]">
              {text.searchResults}
            </h1>
          </div>

          {searchIsReady && !loading && searchCompleted && (
            <p className="rounded-full bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-500 shadow-[0_8px_24px_rgba(0,0,0,0.05)] ring-1 ring-zinc-100 md:text-sm">
              {results.length} {copy.result}
            </p>
          )}
        </div>

        {!searchIsReady && (
          <div className="space-y-5 rounded-[22px] border border-zinc-200/70 bg-white p-5 shadow-[0_12px_34px_rgba(0,0,0,0.035)] md:p-6">
            {recentSearches.length > 0 && (
              <div>
                <div className="mb-3 flex items-center justify-between gap-4">
                  <p className="flex items-center gap-2 text-sm font-bold text-zinc-800">
                    <FiClock className="text-zinc-400" />
                    {copy.recent}
                  </p>

                  <button
                    type="button"
                    onClick={clearRecentSearches}
                    className="text-xs font-bold text-zinc-400 transition hover:text-zinc-950"
                  >
                    {copy.clear}
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((item) => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => selectSearchKeyword(item)}
                      className="rounded-full bg-zinc-100 px-4 py-2 text-sm font-semibold text-zinc-700 transition hover:bg-zinc-950 hover:text-white active:scale-95"
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <p className="mb-3 flex items-center gap-2 text-sm font-bold text-zinc-800">
                <FiTrendingUp className="text-zinc-400" />
                {copy.popular}
              </p>

              <div className="flex flex-wrap gap-2">
                {popularSearches.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => selectSearchKeyword(item)}
                    className="rounded-full border border-zinc-200 bg-white px-4 py-2 text-sm font-semibold text-zinc-700 transition hover:border-zinc-950 hover:text-zinc-950 active:scale-95"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {searchIsReady && loading && (
          <SearchResultsSkeleton count={6} />
        )}

        {searchIsReady &&
          !loading &&
          searchCompleted &&
          results.length === 0 && (
            <div className="rounded-[22px] border border-zinc-200/70 bg-white p-6 text-sm font-semibold text-zinc-500 shadow-[0_12px_34px_rgba(0,0,0,0.035)]">
              {text.searchNotFound}
            </div>
          )}

        {searchIsReady && !loading && results.length > 0 && (
          <div className="space-y-3 pb-12">
            {results.map((product, index) => {
              const productId = getProductId(product);

              if (!productId) return null;

              const image = getProductImage(product);
              const name =
                product.name ||
                product.productName ||
                product.model ||
                "Məhsul";

              const meta =
                product.brandName ||
                product.model ||
                product.productCode ||
                product.categoryName ||
                "nemesisbaku";

              const {
                originalPrice,
                sellingPrice,
                hasDiscount,
                discountPercent,
              } = getProductPrices(product);

              return (
                <NavLink
                  key={productId}
                  to={`/products/${productId}`}
                  state={{
                    fromSearch: true,
                    returnTo: `${location.pathname}${location.search}`,
                  }}
                  onClick={handleProductOpen}
                  className="group flex items-center gap-4 overflow-hidden rounded-[20px] border border-zinc-200/70 bg-white p-3 shadow-[0_10px_30px_rgba(0,0,0,0.035)] transition duration-300 hover:-translate-y-0.5 hover:border-zinc-300 hover:shadow-[0_18px_45px_rgba(0,0,0,0.075)] active:scale-[0.99] md:gap-5 md:p-4"
                  style={{
                    animation: `searchResultIn 400ms cubic-bezier(0.22,1,0.36,1) ${
                      Math.min(index, 8) * 35
                    }ms both`,
                  }}
                >
                  <div className="relative h-[92px] w-[92px] shrink-0 overflow-hidden rounded-[16px] bg-zinc-100 md:h-[112px] md:w-[112px]">
                    {image ? (
                      <img
                        src={image}
                        alt={name}
                        loading="lazy"
                        decoding="async"
                        draggable="false"
                        className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="grid h-full w-full place-items-center text-zinc-300">
                        <FiImage className="text-[28px]" />
                      </div>
                    )}

                    {hasDiscount && (
                      <span className="absolute left-2 top-2 rounded-full bg-red-600 px-2 py-1 text-[9px] font-extrabold text-white">
                        -{discountPercent}%
                      </span>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[10px] font-extrabold uppercase tracking-[0.15em] text-zinc-400 md:text-[11px]">
                      {meta}
                    </p>

                    <h2 className="mt-1 line-clamp-2 text-[14px] font-extrabold leading-5 text-zinc-950 md:text-[16px] md:leading-6">
                      {name}
                    </h2>

                    <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1">
                      {sellingPrice > 0 && (
                        <p
                          className={`text-[15px] font-extrabold ${
                            hasDiscount
                              ? "text-red-600"
                              : "text-zinc-950"
                          }`}
                        >
                          {money(sellingPrice)}
                        </p>
                      )}

                      {hasDiscount && (
                        <p className="text-xs font-bold text-zinc-400 line-through">
                          {money(originalPrice)}
                        </p>
                      )}
                    </div>
                  </div>

                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-zinc-100 text-lg text-zinc-800 transition group-hover:bg-zinc-950 group-hover:text-white">
                    <FiArrowUpRight />
                  </span>
                </NavLink>
              );
            })}
          </div>
        )}
      </section>

      <style>{`
        @keyframes searchResultIn {
          from {
            opacity: 0;
            transform: translateY(14px);
          }

          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @media (prefers-reduced-motion: reduce) {
          * {
            animation-duration: 1ms !important;
          }
        }
      `}</style>
    </main>
  );
}